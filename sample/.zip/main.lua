fennel = require("lib.fennel").install({correlate=true,
                                    moduleName="lib.fennel"})

package.loaded.fennel = fennel

fennel.path = love.filesystem.getSource() .. "/?.fnl;" ..
   -- love.filesystem.getSource() .. "/src/?.fnl;" ..
   -- "/src/?.fnl;" ..
   "/?.fnl;" ..
   fennel.path

-- https://love2d.org/forums/viewtopic.php?t=83142
love.filesystem.setRequirePath("?.lua;?/init.lua;src/?.lua;")


pp = function (text)
   print (fennel.view (text))
   io.flush()
end

require("src.wrap")
